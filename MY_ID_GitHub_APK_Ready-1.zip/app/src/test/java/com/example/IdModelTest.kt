package com.example

import com.example.data.SampleData
import com.example.ui.components.maskDocumentNumber
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IdModelTest {
    @Test
    fun defaultCards_arePopulated() {
        val cards = SampleData.getDefaultCards()
        assertTrue(cards.isNotEmpty())
        assertEquals(5, cards.size)
        assertEquals("Sarah L. Chen", cards[0].holderName)
    }

    @Test
    fun documentNumber_maskingWorks() {
        val masked = maskDocumentNumber("USA-8492-7104-NC")
        assertEquals("USA •••• 4-NC", masked)
    }

    @Test
    fun defaultPortals_hasAll20ItemsWithValidUrls() {
        val portals = com.example.ui.screens.defaultPortals
        assertEquals(20, portals.size)
        assertEquals("Birth Certificate", portals[0].title)
        assertEquals("Civil Registration System", portals[0].subtitle)
        assertEquals("https://crsorgi.gov.in", portals[0].officialUrl)
        assertTrue(portals[0].subServices.isNotEmpty())

        assertEquals("Aadhaar Card", portals[1].title)
        assertEquals("https://myaadhaar.uidai.gov.in/genricDownloadAadhaar", portals[1].subServices[0].targetUrl)

        assertEquals("Insurance Certificate", portals[19].title)
        assertEquals("https://bimabharosa.irdai.gov.in", portals[19].officialUrl)

        portals.forEach { item ->
            assertTrue(item.title.isNotBlank())
            assertTrue(item.subtitle.isNotBlank())
            assertTrue(item.officialUrl.startsWith("https://"))
            assertTrue(item.subServices.isNotEmpty())
        }
    }
}
