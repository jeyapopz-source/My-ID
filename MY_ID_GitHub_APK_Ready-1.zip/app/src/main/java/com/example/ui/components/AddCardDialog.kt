package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.IdCardEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCardDialog(
    onDismiss: () -> Unit,
    onCardAdded: (IdCardEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var holderName by remember { mutableStateOf("Sarah L. Chen") }
    var documentNumber by remember { mutableStateOf("") }
    var issuingAuthority by remember { mutableStateOf("") }
    var expiryDate by remember { mutableStateOf("15 Oct 2028") }
    var selectedCategory by remember { mutableStateOf("Government") }
    var selectedTheme by remember { mutableStateOf("BLUE_VORTEX") }
    var dateOfBirth by remember { mutableStateOf("22 Aug 1994") }
    var address by remember { mutableStateOf("742 Evergreen Terr, Springfield, OR") }
    var additionalNotes by remember { mutableStateOf("") }

    val categories = listOf("Government", "Corporate", "Healthcare", "Academic", "Travel")
    val themes = listOf(
        "BLUE_VORTEX" to Color(0xFF0D47A1),
        "ORANGE_AMBER" to Color(0xFFE65100),
        "EMERALD_SHIELD" to Color(0xFF00796B),
        "CARBON_BLACK" to Color(0xFF263238),
        "ROYAL_PURPLE" to Color(0xFF512DA8)
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("add_card_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Add Digital Credential",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp).testTag("close_add_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Card Type / Category Chips
                Text(
                    text = "CATEGORY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.drop(3).forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Inputs
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Credential Title (e.g. State ID)") },
                    modifier = Modifier.fillMaxWidth().testTag("add_card_title_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = holderName,
                    onValueChange = { holderName = it },
                    label = { Text("Legal Cardholder Name") },
                    modifier = Modifier.fillMaxWidth().testTag("add_card_holder_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = documentNumber,
                    onValueChange = { documentNumber = it },
                    label = { Text("Document / License Number") },
                    modifier = Modifier.fillMaxWidth().testTag("add_card_docnum_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = issuingAuthority,
                    onValueChange = { issuingAuthority = it },
                    label = { Text("Issuing Authority (e.g. Dept of Transport)") },
                    modifier = Modifier.fillMaxWidth().testTag("add_card_issuer_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = expiryDate,
                        onValueChange = { expiryDate = it },
                        label = { Text("Expiry Date") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = dateOfBirth,
                        onValueChange = { dateOfBirth = it },
                        label = { Text("Birth Date") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Theme Palette Selector
                Text(
                    text = "CARD DESIGN THEME",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    themes.forEach { (themeKey, color) ->
                        val isSelected = selectedTheme == themeKey
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { selectedTheme = themeKey }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val cardTitle = title.ifBlank { "$selectedCategory Credential" }
                        val docNum = documentNumber.ifBlank { "ID-" + (1000..9999).random() + "-SEC" }
                        val issuer = issuingAuthority.ifBlank { "Official Identity Registrar" }
                        val newCard = IdCardEntity(
                            cardType = when (selectedCategory) {
                                "Government" -> "NATIONAL_ID"
                                "Corporate" -> "WORK_BADGE"
                                "Healthcare" -> "HEALTH_CARD"
                                "Travel" -> "PASSPORT"
                                else -> "STUDENT_ID"
                            },
                            title = cardTitle,
                            holderName = holderName.ifBlank { "Sarah L. Chen" },
                            documentNumber = docNum,
                            issuingAuthority = issuer,
                            issueDate = "Today",
                            expiryDate = expiryDate,
                            category = selectedCategory,
                            status = "VERIFIED",
                            securityLevel = "eIDAS / Biometric Certified",
                            qrPayload = "did:myid:custom:${docNum}?iss=${issuer.replace(" ", "")}",
                            barcodePayload = docNum.replace("-", ""),
                            themeGradient = selectedTheme,
                            dateOfBirth = dateOfBirth,
                            address = address,
                            emergencyContact = "Registered",
                            mrzCode = "ID<USA<${docNum}<<<<<<<<<<<\n${holderName.replace(" ", "<").uppercase()}<<<<<<<<<<<<<<<<<<01"
                        )
                        onCardAdded(newCard)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_add_card"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Issue to My ID Vault", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
