package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class SubService(
    val title: String,
    val description: String,
    val targetUrl: String? = null
)

data class PortalItem(
    val title: String,
    val subtitle: String,
    val officialUrl: String,
    val subServices: List<SubService> = emptyList()
)

val defaultPortals = listOf(
    PortalItem(
        "Birth Certificate",
        "Civil Registration System",
        "https://crsorgi.gov.in",
        listOf(
            SubService("பிறப்புப் பதிவு மற்றும் நிலை", "புதிய பிறப்புப் பதிவு செய்தல் மற்றும் விண்ணப்ப நிலை சரிபார்த்தல்."),
            SubService("சான்றிதழ் பதிவிறக்கம்", "பிறந்த தேதி சான்றிதழை ஆன்லைனில் டவுன்லோட் செய்தல்."),
            SubService("Official Government Portal", "CRS அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Aadhaar Card",
        "UIDAI Official Portal",
        "https://uidai.gov.in",
        listOf(
            SubService(
                "இ-ஆதார் டவுன்லோட்",
                "பாஸ்வேர்ட் பாதுகாப்போடு டிஜிட்டல் ஆதார் கார்டை PDF-ஆகப் பதிவிறக்கம் செய்தல்.",
                "https://myaadhaar.uidai.gov.in/genricDownloadAadhaar"
            ),
            SubService("பிவிசி கார்டு ஆர்டர்", "பிளாஸ்டிக் ஏடிஎம் கார்டு போன்ற ஆதார் கார்டை தபாலில் வரவழைக்க ஆர்டர் செய்தல்."),
            SubService("Official Government Portal", "UIDAI அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Community Certificate",
        "TNeGA / e-Sevai Portal",
        "https://esevai.tn.gov.in",
        listOf(
            SubService("சாதிச் சான்றிதழ் விண்ணப்பம்", "சாதிச் சான்றிதழுக்கு ஆன்லைனில் விண்ணப்பிப்பது."),
            SubService("Official Government Portal", "e-Sevai அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "TC",
        "School Education Portal - Transfer Certificate",
        "https://tnschools.gov.in",
        listOf(
            SubService("பள்ளி மாற்றுச் சான்றிதழ்", "பள்ளிக்கல்வித்துறை போர்டல் மூலம் மாணவர் தகவல்களைச் சரிபார்த்தல்."),
            SubService("Official Government Portal", "பள்ளிக்கல்வித்துறை அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Mark Sheet",
        "Directorate of Government Examinations (TN DGE)",
        "https://dge.tn.gov.in",
        listOf(
            SubService("மதிப்பெண் பட்டியல் பதிவிறக்கம்", "10 மற்றும் 12-ஆம் வகுப்பு மதிப்பெண் தாள்களைப் பெறுவது."),
            SubService("Official Government Portal", "TN DGE அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "PAN Card",
        "Income Tax & NSDL e-Gov Services",
        "https://www.onlineservices.nsdl.com",
        listOf(
            SubService("இன்ஸ்டன்ட் இ-பான்", "ஆதார் மூலம் உடனடி இ-பான் கார்டு பெறுவது."),
            SubService("Official Government Portal", "NSDL அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Voter ID",
        "Election Commission of India (ECI)",
        "https://voters.eci.gov.in",
        listOf(
            SubService("வாக்காளர் அடையாள அட்டை", "புதிய வாக்காளர் அட்டை மற்றும் திருத்தங்கள்."),
            SubService("Official Government Portal", "ECI அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Passport",
        "Passport Seva Portal, MEA India",
        "https://passportindia.gov.in",
        listOf(
            SubService("பாஸ்போர்ட் விண்ணப்பம்", "புதிய பாஸ்போர்ட் மற்றும் அப்பாயிண்ட்மென்ட்."),
            SubService("Official Government Portal", "பாஸ்போர்ட் சேவா அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Driving Licence",
        "Sarathi Parivahan Sewa, MoRTH",
        "https://sarathi.parivahan.gov.in",
        listOf(
            SubService("ஓட்டுநர் உரிம சேவைகள்", "DL டவுன்லோட், எல்.எல் மற்றும் புதுப்பித்தல்."),
            SubService("Official Government Portal", "சாரதி பரிவாகன் அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "RC",
        "Vehicle Registration (Vahan Parivahan)",
        "https://vahan.parivahan.gov.in",
        listOf(
            SubService("வாகனப் பதிவு விவரங்கள்", "வாகனத்தின் ஆர்சி, இன்சூரன்ஸ் விவரங்கள் சரிபார்த்தல்."),
            SubService("Official Government Portal", "வாகன் பரிவாகன் அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Marriage Certificate",
        "TNREGINET Registration Department",
        "https://tnreginet.gov.in",
        listOf(
            SubService("திருமணப் பதிவு", "ஆன்லைனில் திருமணச் சான்றிதழ் பதிவு மற்றும் தேடுதல்."),
            SubService("Official Government Portal", "TNREGINET அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Smart Card/Ration Card",
        "Tamil Nadu Public Distribution System (TN PDS)",
        "https://tnpds.gov.in",
        listOf(
            SubService("குடும்ப அட்டை சேவைகள்", "ஸ்மார்ட் கார்டு முகவரி மாற்றம், உறுப்பினர் சேர்த்தல்."),
            SubService("Official Government Portal", "TNPDS அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "EC",
        "Encumbrance Certificate (TNREGINET)",
        "https://tnreginet.gov.in",
        listOf(
            SubService("வில்லங்கச் சான்றிதழ் (EC)", "சொத்து வில்லங்கச் சான்றிதழ் தேடுதல் மற்றும் பதிவிறக்கம்."),
            SubService("Official Government Portal", "TNREGINET அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "UAN/PF",
        "Employees' Provident Fund Organization (EPFO)",
        "https://unifiedportal-mem.epfindia.gov.in",
        listOf(
            SubService("பிஎஃப் பாஸ்புக் & கிளைம்", "UAN லாகின், பாஸ்புக் பேலன்ஸ் மற்றும் பணம் பெறுதல்."),
            SubService("Official Government Portal", "EPFO உறுப்பினர் போர்டலுக்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Kisan ID",
        "PM Kisan Samman Nidhi Portal",
        "https://pmkisan.gov.in",
        listOf(
            SubService("விவசாயி நிலை & தவணை விவரம்", "கிசான் தவணை வரவு மற்றும் இ-கேஒய்சி சரிபார்த்தல்."),
            SubService("Official Government Portal", "PM Kisan அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Electricity Bill",
        "TANGEDCO Online Payment & Services",
        "https://www.tnebnet.org",
        listOf(
            SubService("மின்கட்டணம் செலுத்துதல்", "ஆன்லைன் கரண்ட் பில் பேமெண்ட் மற்றும் ரசீது."),
            SubService("Official Government Portal", "TANGEDCO அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Water Tax",
        "Metro Water Supply & Urban Tax Portal",
        "https://chennaimetrowater.tn.gov.in",
        listOf(
            SubService("குடிநீர் வரி செலுத்துதல்", "மெட்ரோ குடிநீர் வரி மற்றும் கழிவுநீர் வரி பேமெண்ட்."),
            SubService("Official Government Portal", "MetroWater அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Gas",
        "MyLPG Official Portal (Indane, Bharat, HP)",
        "https://www.mylpg.in",
        listOf(
            SubService("எல்பிஜி சிலிண்டர் புக்கிங்", "சிலிண்டர் முன்பதிவு மற்றும் மானிய நிலை சரிபார்த்தல்."),
            SubService("Official Government Portal", "MyLPG அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Property Tax",
        "TN Urban Local Bodies Online Tax Portal",
        "https://tnurbanepay.tn.gov.in",
        listOf(
            SubService("நகராட்சி சொத்து வரி", "சொத்து வரி கணக்கீடு மற்றும் ஆன்லைன் செலுத்துதல்."),
            SubService("Official Government Portal", "TN Urban e-Pay அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    ),
    PortalItem(
        "Insurance Certificate",
        "IRDAI Bima Bharosa Insurance Portal",
        "https://bimabharosa.irdai.gov.in",
        listOf(
            SubService("இன்சூரன்ஸ் பாலிசி சேவைகள்", "வாகன மற்றும் பொது இன்சூரன்ஸ் சரிபார்ப்பு."),
            SubService("Official Government Portal", "IRDAI அதிகாரப்பூர்வ வலைத்தளத்திற்குச் செல்லவும்.")
        )
    )
)

@Composable
fun PortalIdsScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }

    val filteredPortals = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            defaultPortals
        } else {
            val q = searchQuery.trim().lowercase()
            defaultPortals.filter {
                it.title.lowercase().contains(q) ||
                it.subtitle.lowercase().contains(q)
            }
        }
    }

    fun launchDirectUrl(urlString: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urlString)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Cannot open URL: $urlString", Toast.LENGTH_SHORT).show()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0E21))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Clean Top Header - App Title: MY ID (No tagline, No bottom nav bar)
            Surface(
                color = Color(0xFF141A32),
                tonalElevation = 4.dp,
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Blue Fingerprint Icon badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1A73E8).copy(alpha = 0.15f))
                                .border(1.dp, Color(0xFF1A73E8).copy(alpha = 0.4f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = "MY ID",
                                tint = Color(0xFF1A73E8),
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // App Title clearly displayed
                        Text(
                            text = "MY ID",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp,
                            modifier = Modifier.testTag("home_app_title")
                        )
                    }

                    // 20 Portals Badge with National Tricolor Accent Bar
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .background(Color(0xFF1C2242), shape = RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(14.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color(0xFFFF9933))
                        )
                        Text(
                            text = "20 Portals",
                            color = Color(0xFFE0E0E0),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Quick Search Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                TextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "தேவையான சேவையைத் தேடவும்... (Search)",
                            color = Color(0xFF888899),
                            fontSize = 14.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = Color(0xFF1A73E8)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = Color.Gray
                                )
                            }
                        }
                    },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF141A32),
                        unfocusedContainerColor = Color(0xFF141A32),
                        disabledContainerColor = Color(0xFF141A32),
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF283155), RoundedCornerShape(12.dp))
                        .testTag("portal_search_input")
                )
            }

            // 20 Official Government Service Cards List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (filteredPortals.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "சேவைகள் எதுவும் கிடைக்கவில்லை.\nNo portals found matching \"$searchQuery\"",
                                color = Color.Gray,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    items(filteredPortals, key = { it.title }) { portal ->
                        PortalServiceCard(
                            portal = portal,
                            onClick = { launchDirectUrl(portal.officialUrl) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Service Card with:
 * - Professional light-dark national tricolor-themed shadow and border effect
 * - Blue-colored Fingerprint icon centered in the icon section (Strictly NO Ashoka Chakra)
 * - Direct, clean, and fast navigation to the official URL
 */
@Composable
fun PortalServiceCard(
    portal: PortalItem,
    onClick: () -> Unit
) {
    // Professional light-dark national tricolor-themed shadow effect
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(14.dp),
                ambientColor = Color(0xFFFF9933).copy(alpha = 0.35f), // National Saffron shadow
                spotColor = Color(0xFF138808).copy(alpha = 0.45f)      // National Green shadow
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFFFF9933).copy(alpha = 0.55f), // Saffron
                        Color(0xFFFFFFFF).copy(alpha = 0.20f), // White
                        Color(0xFF138808).copy(alpha = 0.55f)  // Green
                    )
                ),
                shape = RoundedCornerShape(14.dp)
            )
            .background(
                color = Color(0xFF15192E),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(14.dp)
            .testTag("portal_card_${portal.title.replace(" ", "_")}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Blue-colored Fingerprint Icon container (Strictly NO Ashoka Chakra)
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1A73E8).copy(alpha = 0.12f))
                    .border(1.dp, Color(0xFF1A73E8).copy(alpha = 0.35f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Fingerprint,
                    contentDescription = "Blue Fingerprint Icon",
                    tint = Color(0xFF1A73E8), // Blue-colored Fingerprint icon
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Title and Subtitle Info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = portal.title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = portal.subtitle,
                    color = Color(0xFF9EA7C4),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Official URL indicator badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Official Link",
                        tint = Color(0xFF4DA6FF),
                        modifier = Modifier.size(11.dp)
                    )
                    Text(
                        text = portal.officialUrl.removePrefix("https://").removeSuffix("/"),
                        color = Color(0xFF4DA6FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Fast Navigation Arrow
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF202646)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Navigate to ${portal.title}",
                    tint = Color(0xFFE0E0E0),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
