package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.IdCardEntity
import kotlin.math.sin

@Composable
fun IdCardView(
    card: IdCardEntity,
    isMasked: Boolean,
    modifier: Modifier = Modifier,
    isFlipped: Boolean = false,
    onFlip: () -> Unit = {},
    onPinToggle: (() -> Unit)? = null,
    onClick: (() -> Unit)? = null
) {
    val rotation by animateFloatAsState(
        targetValue = if (isFlipped) 180f else 0f,
        animationSpec = tween(500),
        label = "cardFlip"
    )

    val isBackShowing = rotation > 90f

    val gradient = getCardGradient(card.themeGradient)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(210.dp)
            .graphicsLayer {
                rotationY = rotation
                cameraDistance = 12f * density
            }
            .clip(RoundedCornerShape(20.dp))
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.4f),
                        Color.White.copy(alpha = 0.05f)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable(enabled = onClick != null) { onClick?.invoke() }
            .testTag("id_card_${card.id}"),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(gradient)
        ) {
            // Anti-counterfeit guilloche pattern
            GuillocheBackground()

            if (isBackShowing) {
                // Render back face reversed so text is upright
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { rotationY = 180f }
                ) {
                    CardBackView(
                        card = card,
                        isMasked = isMasked,
                        onFlip = onFlip
                    )
                }
            } else {
                CardFrontView(
                    card = card,
                    isMasked = isMasked,
                    onFlip = onFlip,
                    onPinToggle = onPinToggle
                )
            }
        }
    }
}

@Composable
private fun CardFrontView(
    card: IdCardEntity,
    isMasked: Boolean,
    onFlip: () -> Unit,
    onPinToggle: (() -> Unit)?
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Row: Authority & Badges
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Official seal glyph
                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Official Security Seal",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Column {
                    Text(
                        text = card.issuingAuthority.uppercase(),
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.8.sp,
                        maxLines = 1
                    )
                    Text(
                        text = card.title,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onPinToggle != null) {
                    IconButton(
                        onClick = onPinToggle,
                        modifier = Modifier.size(32.dp).testTag("pin_button_${card.id}")
                    ) {
                        Icon(
                            imageVector = if (card.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Pin Card",
                            tint = if (card.isPinned) Color(0xFFFFD54F) else Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onFlip,
                    modifier = Modifier.size(32.dp).testTag("flip_button_${card.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Flip Card",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Middle Row: Metallic Chip, NFC Icon & Hologram
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                EmvChip()
                Icon(
                    imageVector = Icons.Default.Nfc,
                    contentDescription = "Contactless ID",
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(22.dp)
                )
            }

            // Holographic Badge
            HolographicBadge(status = card.status)
        }

        // Bottom Row: Card Details
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Column {
                Text(
                    text = "CARDHOLDER",
                    color = Color.White.copy(alpha = 0.65f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.sp
                )
                Text(
                    text = card.holderName.uppercase(),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isMasked) maskDocumentNumber(card.documentNumber) else card.documentNumber,
                    color = Color.White.copy(alpha = 0.95f),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "EXPIRES",
                    color = Color.White.copy(alpha = 0.65f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.sp
                )
                Text(
                    text = card.expiryDate,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                // Status pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (card.status == "VERIFIED") Color(0xFF00E676).copy(alpha = 0.25f)
                    else Color(0xFF00B0FF).copy(alpha = 0.25f),
                    border = BorderStroke(
                        0.5.dp,
                        if (card.status == "VERIFIED") Color(0xFF00E676).copy(alpha = 0.6f)
                        else Color(0xFF00B0FF).copy(alpha = 0.6f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (card.status == "VERIFIED") Color(0xFF00E676) else Color(0xFF00B0FF),
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = card.status,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CardBackView(
    card: IdCardEntity,
    isMasked: Boolean,
    onFlip: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Magnetic stripe
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp)
                .background(Color(0xFF090D1A))
        )

        // Middle details & emergency
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "SPEC: ${card.securityLevel}",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (card.bloodType.isNotBlank()) {
                    Text(
                        text = "MEDICAL: ${card.bloodType}",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 10.sp
                    )
                }
                if (card.emergencyContact.isNotBlank()) {
                    Text(
                        text = "EMERGENCY: ${card.emergencyContact}",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 9.sp
                    )
                }
            }

            IconButton(
                onClick = onFlip,
                modifier = Modifier.size(32.dp).testTag("flip_back_button_${card.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = "Flip Back",
                    tint = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // MRZ Code or Barcode Zone
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.White.copy(alpha = 0.15f))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(
                text = card.mrzCode.ifBlank { "ID<USA<${card.documentNumber}<<<<<<<<<<<\n${card.holderName.replace(" ", "<").uppercase()}<<<<<<<<<<<<<<<<<<01" },
                color = Color.White,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.5.sp,
                lineHeight = 12.sp,
                letterSpacing = 1.1.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun EmvChip() {
    Surface(
        modifier = Modifier
            .width(38.dp)
            .height(28.dp),
        shape = RoundedCornerShape(6.dp),
        color = Color(0xFFFFD54F),
        border = BorderStroke(0.8.dp, Color(0xFFFFA000))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeColor = Color(0xFFC78C06)
            val stroke = Stroke(width = 1.5f)
            // Chip internal division lines
            drawLine(
                strokeColor,
                Offset(size.width * 0.35f, 0f),
                Offset(size.width * 0.35f, size.height),
                strokeWidth = 1.5f
            )
            drawLine(
                strokeColor,
                Offset(size.width * 0.65f, 0f),
                Offset(size.width * 0.65f, size.height),
                strokeWidth = 1.5f
            )
            drawLine(
                strokeColor,
                Offset(0f, size.height * 0.5f),
                Offset(size.width, size.height * 0.5f),
                strokeWidth = 1.5f
            )
        }
    }
}

@Composable
private fun HolographicBadge(status: String) {
    Surface(
        modifier = Modifier.size(36.dp),
        shape = CircleShape,
        color = Color.Transparent,
        border = BorderStroke(
            1.dp,
            Brush.sweepGradient(
                listOf(
                    Color(0xFF00E5FF),
                    Color(0xFFFF9100),
                    Color(0xFF00E676),
                    Color(0xFFE040FB),
                    Color(0xFF00E5FF)
                )
            )
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.35f),
                            Color.Transparent
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "ID",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
private fun GuillocheBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val path = Path()
        val amplitude = 20f
        val frequency = 0.05f
        val stroke = Stroke(width = 0.75f)

        for (offsetY in 15..210 step 25) {
            path.reset()
            path.moveTo(0f, offsetY.toFloat())
            var x = 0f
            while (x < size.width) {
                val y = offsetY + sin(x * frequency) * amplitude
                path.lineTo(x, y.toFloat())
                x += 10f
            }
            drawPath(
                path = path,
                color = Color.White.copy(alpha = 0.06f),
                style = stroke
            )
        }
    }
}

fun getCardGradient(themeName: String): Brush {
    return when (themeName) {
        "ORANGE_AMBER" -> Brush.linearGradient(
            colors = listOf(
                Color(0xFFD84315),
                Color(0xFFF57C00),
                Color(0xFFFFB300)
            )
        )
        "EMERALD_SHIELD" -> Brush.linearGradient(
            colors = listOf(
                Color(0xFF004D40),
                Color(0xFF00796B),
                Color(0xFF00BFA5)
            )
        )
        "CARBON_BLACK" -> Brush.linearGradient(
            colors = listOf(
                Color(0xFF111827),
                Color(0xFF1F2937),
                Color(0xFF374151)
            )
        )
        "ROYAL_PURPLE" -> Brush.linearGradient(
            colors = listOf(
                Color(0xFF311B92),
                Color(0xFF512DA8),
                Color(0xFF7E57C2)
            )
        )
        else -> Brush.linearGradient(
            colors = listOf(
                Color(0xFF08296D), // Brand deep blue
                Color(0xFF0D47A1),
                Color(0xFF0091EA)
            )
        )
    }
}

fun maskDocumentNumber(docNum: String): String {
    if (docNum.length <= 4) return "•••• $docNum"
    val prefix = docNum.take(3)
    val suffix = docNum.takeLast(4)
    return "$prefix •••• $suffix"
}
