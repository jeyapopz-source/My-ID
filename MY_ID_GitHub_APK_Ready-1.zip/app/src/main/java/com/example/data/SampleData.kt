package com.example.data

object SampleData {
    fun getDefaultCards(): List<IdCardEntity> {
        return listOf(
            IdCardEntity(
                id = 1,
                cardType = "NATIONAL_ID",
                title = "National Identity Card",
                holderName = "Sarah L. Chen",
                documentNumber = "USA-8492-7104-NC",
                issuingAuthority = "U.S. Dept. of Homeland Security",
                issueDate = "14 Oct 2023",
                expiryDate = "14 Oct 2033",
                category = "Government",
                status = "VERIFIED",
                securityLevel = "Biometric e-Pass / Tier 3",
                qrPayload = "did:myid:dhs:cred:8492-7104?sec=ECDSA-P256&exp=2033-10-14&iss=DHS-GOV",
                barcodePayload = "USA84927104NC",
                themeGradient = "BLUE_VORTEX",
                isPinned = true,
                dateOfBirth = "22 Aug 1994",
                address = "742 Evergreen Terr, Springfield, OR",
                departmentOrClass = "Class A Citizenship",
                bloodType = "O+",
                emergencyContact = "+1 (555) 019-2834",
                mrzCode = "IDUSA84927104NC8<<<<<<<<<<<<<<<\n9408224F3310148USA<<<<<<<<<<<4\nCHEN<<SARAH<L<<<<<<<<<<<<<<<<<"
            ),
            IdCardEntity(
                id = 2,
                cardType = "DRIVERS_LICENSE",
                title = "Mobile Driver's License (mDL)",
                holderName = "Sarah L. Chen",
                documentNumber = "DL-9028-5412-OR",
                issuingAuthority = "Oregon Dept. of Motor Vehicles",
                issueDate = "05 Mar 2024",
                expiryDate = "05 Mar 2029",
                category = "Government",
                status = "VERIFIED",
                securityLevel = "ISO/IEC 18013-5 Compliant",
                qrPayload = "mdl:org.iso.18013.5:OR-90285412?digest=4a9f82d1c6e&ts=1727694000",
                barcodePayload = "OR90285412C",
                themeGradient = "ORANGE_AMBER",
                isPinned = true,
                dateOfBirth = "22 Aug 1994",
                address = "742 Evergreen Terr, Springfield, OR",
                departmentOrClass = "Class C • Endorsement: None",
                bloodType = "O+ (Organ Donor: YES)",
                emergencyContact = "+1 (555) 019-2834",
                mrzCode = "DLUSA90285412OR<<<<<<<<<<<<<<<\n9408224F2903058USA<<<<<<<<<<<1\nCHEN<<SARAH<L<<<<<<<<<<<<<<<<<"
            ),
            IdCardEntity(
                id = 3,
                cardType = "WORK_BADGE",
                title = "Nexlify Corporate Security Badge",
                holderName = "Sarah L. Chen",
                documentNumber = "NX-EMP-0842",
                issuingAuthority = "Nexlify Global Identity Ops",
                issueDate = "10 Jan 2025",
                expiryDate = "10 Jan 2027",
                category = "Corporate",
                status = "ACTIVE",
                securityLevel = "FIDO2 / Hardware NFC Element",
                qrPayload = "fido:corp:nexlify:emp:0842?zone=ALL_FACILITIES&clearance=L4",
                barcodePayload = "NXEMP0842L4",
                themeGradient = "CARBON_BLACK",
                isPinned = false,
                dateOfBirth = "22 Aug 1994",
                address = "San Francisco Technology HQ",
                departmentOrClass = "Principal Security Architect • SecOps",
                bloodType = "O+",
                emergencyContact = "corp-security@nexlify.com",
                mrzCode = "NX<<CORP<STAFF<<<<<<<<<<<<<<<<\n0842CHEN<<SARAH<PRINCIPAL<<<<<"
            ),
            IdCardEntity(
                id = 4,
                cardType = "HEALTH_CARD",
                title = "MedShield Global Health Pass",
                holderName = "Sarah L. Chen",
                documentNumber = "MED-44109-9821",
                issuingAuthority = "MedShield Healthcare Alliance",
                issueDate = "01 Jan 2026",
                expiryDate = "31 Dec 2026",
                category = "Healthcare",
                status = "VERIFIED",
                securityLevel = "HIPAA Compliant Verifiable Pass",
                qrPayload = "shc:/567629095311014822600012015011234890",
                barcodePayload = "MED441099821",
                themeGradient = "EMERALD_SHIELD",
                isPinned = false,
                dateOfBirth = "22 Aug 1994",
                address = "Plan Network: Tier 1 Global PPO",
                departmentOrClass = "Group #9941 • RxBIN 014820",
                bloodType = "O+ • Penicillin Allergy",
                emergencyContact = "24/7 MedDesk: +1 (800) 555-4321",
                mrzCode = "MED<<SHIELD<HEALTH<<<<<<<<<<<<\n441099821CHEN<<SARAH<PPO<<<<<<"
            ),
            IdCardEntity(
                id = 5,
                cardType = "PASSPORT",
                title = "Biometric International Passport",
                holderName = "Sarah L. Chen",
                documentNumber = "P89201947",
                issuingAuthority = "Department of State",
                issueDate = "18 Jun 2021",
                expiryDate = "17 Jun 2031",
                category = "Travel",
                status = "VERIFIED",
                securityLevel = "ICAO Doc 9303 / Biometric BAC",
                qrPayload = "icao:epass:USA:P89201947?hash=9f82d1c7e2b10a",
                barcodePayload = "P89201947",
                themeGradient = "ROYAL_PURPLE",
                isPinned = false,
                dateOfBirth = "22 Aug 1994",
                address = "United States of America",
                departmentOrClass = "Nationality: USA • Sex: F",
                bloodType = "O+",
                emergencyContact = "+1 (555) 019-2834",
                mrzCode = "P<USACHEN<<SARAH<L<<<<<<<<<<<<<<<<<<<<<<<\nP892019470USA9408224F3106173<<<<<<<<<<<<<<04"
            )
        )
    }

    fun getDefaultAuditLogs(): List<AuditLogEntity> {
        val now = System.currentTimeMillis()
        return listOf(
            AuditLogEntity(
                id = 1,
                cardTitle = "National Identity Card",
                verifierName = "Airport Security Checkpoint (TSA PreCheck)",
                timestamp = now - (2 * 60 * 60 * 1000L), // 2 hours ago
                attributesShared = "Legal Full Name, Biometric Face Token, Over 21 Confirmation",
                verificationMethod = "NFC_TAP",
                status = "SUCCESS"
            ),
            AuditLogEntity(
                id = 2,
                cardTitle = "Nexlify Corporate Security Badge",
                verifierName = "HQ Main Turnstile - Gate 2",
                timestamp = now - (5 * 60 * 60 * 1000L), // 5 hours ago
                attributesShared = "Employee Token, Access Clearance Level 4",
                verificationMethod = "NFC_TAP",
                status = "SUCCESS"
            ),
            AuditLogEntity(
                id = 3,
                cardTitle = "MedShield Global Health Pass",
                verifierName = "St. Francis Medical Clinic Reception",
                timestamp = now - (2 * 24 * 60 * 60 * 1000L), // 2 days ago
                attributesShared = "Policy ID, Group #, Allergy Warnings",
                verificationMethod = "QR_CODE",
                status = "SUCCESS"
            ),
            AuditLogEntity(
                id = 4,
                cardTitle = "Mobile Driver's License (mDL)",
                verifierName = "Hertz Vehicle Rental Agency",
                timestamp = now - (5 * 24 * 60 * 60 * 1000L), // 5 days ago
                attributesShared = "Driving Privileges Active, Age Over 25, Name",
                verificationMethod = "QR_CODE",
                status = "SUCCESS"
            )
        )
    }
}
